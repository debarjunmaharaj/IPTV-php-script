<?php
// --- Database Configuration ---
define('DB_HOST', 'localhost');
define('DB_USER', 'your_database_user');
define('DB_PASS', 'your_database_password');
define('DB_NAME', 'your_database_name');

// --- OPTIONAL: Only change if your uploads folder is different ---
define('UPLOAD_DIR', 'Uploads/');
?>